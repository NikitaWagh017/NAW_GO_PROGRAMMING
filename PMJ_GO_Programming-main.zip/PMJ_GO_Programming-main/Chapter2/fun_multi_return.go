func addAndMultiply(n1, n2 int) (int, int) {
	sum := n1 + n2
	product := n1 * n2
	return sum, product
}
