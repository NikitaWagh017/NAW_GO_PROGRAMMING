package main

import "fmt"

func main() {
	str := "Hello, Go!"
	fmt.Println("The string is:", str)
}
