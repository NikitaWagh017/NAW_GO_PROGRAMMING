package main

import "fmt"

func main() {
	var a string = "saku"
	var b int = 55
	var c bool = true
	fmt.Println(a)
	fmt.Println(b)
	fmt.Println(c)
}
