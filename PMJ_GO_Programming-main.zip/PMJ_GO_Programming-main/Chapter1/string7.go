package main

import (
	"fmt"
	"strings"
)

func main() {
	str := "golang"
	fmt.Println("Uppercase:", strings.ToUpper(str))
}
