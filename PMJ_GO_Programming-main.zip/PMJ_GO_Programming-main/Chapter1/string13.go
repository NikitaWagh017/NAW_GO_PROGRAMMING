package main

import (
	"fmt"
	"strings"
)

func main() {
	str := "   GoLang   "
	fmt.Println("Trimmed string:", strings.TrimSpace(str))
}
