package main

import "fmt"

func main() {
	var x int = 10
	var y float64 = float64(x)
	fmt.Println("Implicit casting:", y)
}
