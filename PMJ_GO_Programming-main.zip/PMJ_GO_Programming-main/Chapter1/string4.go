package main

import "fmt"

func main() {
	str1 := "GoLang"
	str2 := "GoLang"
	if str1 == str2 {
		fmt.Println("Strings are equal")
	} else {
		fmt.Println("Strings are not equal")
	}
}
