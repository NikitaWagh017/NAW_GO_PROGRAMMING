package main

import "fmt"

func main() {
	result := "hello"[1]
	fmt.Println("Char:", result)
}
