package main

import "fmt"

func main() {
	result := len("hello")
	fmt.Println("Len:", result)
}
