package main

import (
	"fmt"
	"strings"
)

func main() {
	result := strings.ToLower("TEST")
	fmt.Println("ToLower:", result)
}
