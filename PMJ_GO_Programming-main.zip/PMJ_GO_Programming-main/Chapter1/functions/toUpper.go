package main

import (
	"fmt"
	"strings"
)

func main() {
	result := strings.ToUpper("test")
	fmt.Println("ToUpper:", result)
}
