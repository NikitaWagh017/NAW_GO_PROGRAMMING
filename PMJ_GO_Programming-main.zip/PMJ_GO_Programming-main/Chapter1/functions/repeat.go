package main

import (
	"fmt"
	"strings"
)

func main() {
	result := strings.Repeat("a", 5)
	fmt.Println("Repeat:", result)
}
