package main

import "fmt"

func add(a int, b int) {
	fmt.Println("Sum:", a+b)
}

func main() {
	add(5, 3)
}
