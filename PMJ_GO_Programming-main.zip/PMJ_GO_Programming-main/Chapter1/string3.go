package main

import "fmt"

func main() {
	str := "GoLang"
	fmt.Println("Length of the string:", len(str))
}
