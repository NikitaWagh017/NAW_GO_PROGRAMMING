package main

import (
	"fmt"
	"strings"
)

func main() {
	str := "GoLang"
	fmt.Println("Lowercase:", strings.ToLower(str))
}
