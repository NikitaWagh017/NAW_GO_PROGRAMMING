package main
import ("fmt")
func main() {
	var student1 string = "John" //type is string
	var student2 = "Jane" //type is inferred
	x := 2 
	fmt.Println(student1)
	fmt.Println(student2)
	fmt.Println(x)
}