package main

import "fmt"

func main() {
	name := "John"
	age := 25
	fmt.Printf("My name is %s and I am %d years old.\n", name, age)
}
