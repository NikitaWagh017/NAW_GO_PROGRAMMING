package main

import "fmt"

func main() {
	num1 := 5
	num2 := 10
	fmt.Printf("The sum of %d and %d is %d", num1, num2, num1+num2) // Using fmt.Printf()
}
