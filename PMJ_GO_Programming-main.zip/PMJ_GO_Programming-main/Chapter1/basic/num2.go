package main

import "fmt"

func main() {
	fmt.Printf("The number is %d\n", 100)
}
