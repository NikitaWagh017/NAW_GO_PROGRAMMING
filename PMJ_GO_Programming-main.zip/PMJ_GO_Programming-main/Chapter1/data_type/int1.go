package main

import "fmt"

func main() {
	num := 5
	fmt.Println("Integer:", num)
}
