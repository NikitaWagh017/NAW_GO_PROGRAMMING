package main

import "fmt"

func main() {
	isTrue := true
	fmt.Println("Boolean:", isTrue)
}
