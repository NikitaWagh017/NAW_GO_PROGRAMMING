package main

import "fmt"

func main() {
	grade := 'A'
	fmt.Println("Char:", grade)
}
