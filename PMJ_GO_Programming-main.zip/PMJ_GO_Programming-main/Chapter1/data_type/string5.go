package main

import "fmt"

func main() {
	message := "Go Programming"
	fmt.Println("String:", message)
}
