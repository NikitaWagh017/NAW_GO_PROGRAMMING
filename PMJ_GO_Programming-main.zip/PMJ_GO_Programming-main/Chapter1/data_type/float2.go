package main

import "fmt"

func main() {
	pi := 3.14
	fmt.Println("Float:", pi)
}
