package main 
import "fmt"
func main(){
	var arr[4]int
	arr[0]=10
	arr[1]=20
	arr[2]=30
	fmt.Println(arr)
}