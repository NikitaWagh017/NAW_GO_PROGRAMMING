package main

import "fmt"

func main() {
	var x [5]int
	x[4] = 100
	fmt.Println(x)

}
