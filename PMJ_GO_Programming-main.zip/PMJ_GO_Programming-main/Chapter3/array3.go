package main

func main() {
	fruits = []string{"apple", "banana", "cherry"}
	for i, fruit = range fruits {
		fmt.println(i, fruit)
	}
}
