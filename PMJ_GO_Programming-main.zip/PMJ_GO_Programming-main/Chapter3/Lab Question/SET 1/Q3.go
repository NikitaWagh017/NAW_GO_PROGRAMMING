//3. WAP in go language to Initialize a Slice using Multi-Line Syntax and display

package main

import "fmt"

func main() {
	slice := []int{
		10,
		20,
		30,
		40,
		50,
	}

	fmt.Println("Initialized Slice:", slice)
}
