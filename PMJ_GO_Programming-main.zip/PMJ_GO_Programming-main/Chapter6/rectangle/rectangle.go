package rectangle

func Area(length, width float64) float64 {
	return length * width
}
