package main

import (
	"fmt"
	"time"
)

func main() {
	fmt.Println("Start")
	time.Sleep(2 * time.Second) // Sleep for 2 seconds
	fmt.Println("End")
}
